SST Website Assets

Folders:
- icons/ : original SVG icons for History, Geography, Civics, Economics, books, maps, questions and download buttons.
- images/ : original banner and chapter placeholder artwork.
- favicon.svg : website favicon.

Example HTML:
<img src="assets/icons/history.svg" alt="History">
<img src="assets/images/subject-banner.svg" alt="SST Notes">

These are original assets created for this website and can be edited or recolored in the SVG files.
